// ==========================================
// constants/index.ts
// ค่าคงที่ทั้งหมดของแอป
// ==========================================

export const COLORS = {
  bg: '#0a0a0f',
  surface: '#12121a',
  card: '#1a1a26',
  border: '#2a2a3a',
  accent: '#00e5ff',
  accent2: '#7c4dff',
  warn: '#ff6d00',
  danger: '#ff1744',
  safe: '#00e676',
  text: '#e8e8f0',
  muted: '#6b6b88',
};

// ระยะห่างที่ถือว่าอันตราย (เมตร)
export const DANGER_DISTANCE = 2.0;   // อันตรายมาก → สั่น + เสียง
export const WARN_DISTANCE   = 4.0;   // ระวัง → แจ้งเสียง
export const SAFE_DISTANCE   = 6.0;   // ปลอดภัย → ไม่พูด

// ความถี่การส่งภาพไป AI (มิลลิวินาที)
export const CAPTURE_INTERVAL_MS = 1500;

// Prompt ภาษาไทยสำหรับ Claude Vision
export const VISION_PROMPT = `คุณคือระบบช่วยเหลือผู้พิการทางสายตา วิเคราะห์ภาพนี้และตอบด้วย JSON เท่านั้น ห้ามมีข้อความอื่น

ตรวจสอบและระบุ:
1. วัตถุอันตราย: รถ มอเตอร์ไซค์ จักรยาน สุนัข
2. สิ่งกีดขวาง: บันได ขอบฟุตบาท หลุม สิ่งของวางบนทาง
3. ป้ายหรือสัญลักษณ์สำคัญ: ป้ายจราจร ทางม้าลาย สัญญาณไฟ
4. คนที่อยู่ใกล้

ตอบในรูปแบบ JSON นี้เท่านั้น:
{
  "objects": [
    {
      "name": "ชื่อวัตถุภาษาไทย",
      "direction": "ซ้าย/ขวา/หน้า/หลัง",
      "estimatedDistance": 2.5,
      "riskLevel": "danger/warn/safe",
      "speechText": "ข้อความพูดภาษาไทย เช่น รถยนต์ด้านซ้าย 2 เมตร"
    }
  ],
  "overallSafe": true,
  "sceneSummary": "สรุปภาพรวมสั้นๆ ภาษาไทย"
}`;

// ประเภทวัตถุที่ตรวจจับ
export const OBJECT_TYPES = {
  VEHICLE: 'vehicle',
  PERSON: 'person',
  OBSTACLE: 'obstacle',
  STAIRS: 'stairs',
  SIGN: 'sign',
} as const;

// ข้อความเสียงเริ่มต้น
export const SPEECH_MESSAGES = {
  appStart: 'EyeAI พร้อมใช้งาน กำลังเปิดกล้อง',
  cameraReady: 'กล้องพร้อมแล้ว ระบบ AI กำลังทำงาน',
  noInternet: 'ไม่มีอินเทอร์เน็ต กรุณาตรวจสอบการเชื่อมต่อ',
  allClear: 'เส้นทางด้านหน้าปลอดภัย',
  analysisError: 'ไม่สามารถวิเคราะห์ภาพได้ กรุณาลองใหม่',
};
