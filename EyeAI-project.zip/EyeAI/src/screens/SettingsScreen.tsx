// ==========================================
// screens/SettingsScreen.tsx
// หน้าตั้งค่า
// ==========================================

import React, { useState } from 'react';
import {
  View,
  Text,
  Switch,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Alert,
} from 'react-native';
import { useAppStore } from '../store/appStore';
import { COLORS } from '../constants';
import { speak } from '../services/speechService';

export function SettingsScreen({ navigation }: any) {
  const { apiKey, settings, setApiKey, updateSettings } = useAppStore();
  const [inputKey, setInputKey] = useState(apiKey);

  const saveApiKey = () => {
    if (!inputKey.startsWith('sk-ant-')) {
      Alert.alert('❌ API Key ไม่ถูกต้อง', 'Claude API Key ต้องขึ้นต้นด้วย sk-ant-');
      return;
    }
    setApiKey(inputKey.trim());
    Alert.alert('✅ บันทึกแล้ว', 'บันทึก API Key เรียบร้อย');
  };

  const testSpeech = () => {
    speak('ทดสอบเสียงภาษาไทย EyeAI พร้อมช่วยเหลือคุณ', 'high');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backText}>← กลับ</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>⚙️ ตั้งค่า</Text>
        </View>

        {/* API Key */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔑 Claude API Key</Text>
          <TextInput
            style={styles.input}
            value={inputKey}
            onChangeText={setInputKey}
            placeholder="sk-ant-api03-..."
            placeholderTextColor={COLORS.muted}
            secureTextEntry
            autoCapitalize="none"
            autoCorrect={false}
          />
          <Text style={styles.hint}>
            รับ API Key ได้ที่ console.anthropic.com
          </Text>
          <TouchableOpacity style={styles.saveBtn} onPress={saveApiKey}>
            <Text style={styles.saveBtnText}>บันทึก API Key</Text>
          </TouchableOpacity>
        </View>

        {/* เสียงและการสั่น */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔊 เสียงและการสั่น</Text>

          <SettingRow
            label="เสียงแจ้งเตือน"
            value={settings.speechEnabled}
            onToggle={(v) => updateSettings({ speechEnabled: v })}
          />
          <SettingRow
            label="การสั่น"
            value={settings.vibrationEnabled}
            onToggle={(v) => updateSettings({ vibrationEnabled: v })}
          />

          <TouchableOpacity style={styles.testBtn} onPress={testSpeech}>
            <Text style={styles.testBtnText}>🔊 ทดสอบเสียง</Text>
          </TouchableOpacity>
        </View>

        {/* ความถี่การวิเคราะห์ */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>⚡ ความเร็วการวิเคราะห์</Text>
          <Text style={styles.hint}>
            วิเคราะห์ทุก {settings.captureIntervalMs / 1000} วินาที
            (เร็ว = ใช้ API มากขึ้น)
          </Text>
          <View style={styles.speedRow}>
            {[1000, 1500, 2000, 3000].map((ms) => (
              <TouchableOpacity
                key={ms}
                style={[
                  styles.speedBtn,
                  settings.captureIntervalMs === ms && styles.speedBtnActive,
                ]}
                onPress={() => updateSettings({ captureIntervalMs: ms })}
              >
                <Text style={[
                  styles.speedBtnText,
                  settings.captureIntervalMs === ms && styles.speedBtnTextActive,
                ]}>
                  {ms / 1000}s
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ความไวการแจ้งเตือน */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎯 ความไวการแจ้งเตือน</Text>
          <View style={styles.speedRow}>
            {(['low', 'medium', 'high'] as const).map((s) => (
              <TouchableOpacity
                key={s}
                style={[
                  styles.speedBtn,
                  settings.sensitivity === s && styles.speedBtnActive,
                  { flex: 1 },
                ]}
                onPress={() => updateSettings({ sensitivity: s })}
              >
                <Text style={[
                  styles.speedBtnText,
                  settings.sensitivity === s && styles.speedBtnTextActive,
                ]}>
                  {s === 'low' ? 'ต่ำ' : s === 'medium' ? 'ปานกลาง' : 'สูง'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

function SettingRow({
  label, value, onToggle,
}: {
  label: string;
  value: boolean;
  onToggle: (v: boolean) => void;
}) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onToggle}
        trackColor={{ false: COLORS.border, true: COLORS.accent }}
        thumbColor={value ? '#fff' : COLORS.muted}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { padding: 20, gap: 20 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 8,
  },
  backBtn: { padding: 4 },
  backText: { color: COLORS.accent, fontSize: 15 },
  headerTitle: { color: COLORS.text, fontSize: 20, fontWeight: '700' },

  section: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 16,
    gap: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  sectionTitle: {
    color: COLORS.text,
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  hint: { color: COLORS.muted, fontSize: 12, lineHeight: 18 },

  input: {
    backgroundColor: COLORS.surface,
    color: COLORS.text,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    fontFamily: 'monospace',
  },
  saveBtn: {
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  saveBtnText: { color: '#000', fontWeight: '700', fontSize: 15 },

  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowLabel: { color: COLORS.text, fontSize: 14 },

  testBtn: {
    backgroundColor: COLORS.surface,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  testBtnText: { color: COLORS.accent, fontSize: 14, fontWeight: '600' },

  speedRow: { flexDirection: 'row', gap: 8 },
  speedBtn: {
    flex: 1,
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    backgroundColor: COLORS.surface,
  },
  speedBtnActive: { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  speedBtnText: { color: COLORS.muted, fontSize: 13, fontWeight: '600' },
  speedBtnTextActive: { color: '#000' },
});
