// ==========================================
// screens/CameraScreen.tsx
// หน้าจอหลัก — กล้อง + AI Detection
// ==========================================

import React, { useEffect } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Text,
  SafeAreaView,
  Alert,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useCamera } from '../hooks/useCamera';
import { useAppStore } from '../store/appStore';
import { DetectionOverlay } from '../components/DetectionOverlay';
import { AlertBanner } from '../components/AlertBanner';
import { AlertLog } from '../components/AlertLog';
import { COLORS } from '../constants';
import { sayAppStart } from '../services/speechService';

export function CameraScreen({ navigation }: any) {
  const [permission, requestPermission] = useCameraPermissions();
  const { cameraRef } = useCamera();
  const { isActive, isAnalyzing, currentObjects, apiKey, setActive } = useAppStore();

  // วัตถุอันตรายสูงสุดสำหรับ AlertBanner
  const topObject = currentObjects.find((o) => o.riskLevel === 'danger')
    ?? currentObjects.find((o) => o.riskLevel === 'warn')
    ?? null;

  useEffect(() => {
    if (!permission?.granted) {
      requestPermission();
    }
  }, []);

  useEffect(() => {
    if (!apiKey) {
      Alert.alert(
        '⚙️ ตั้งค่า API Key',
        'กรุณาใส่ Claude API Key ในหน้าตั้งค่าก่อนเริ่มใช้งาน',
        [{ text: 'ไปตั้งค่า', onPress: () => navigation.navigate('Settings') }]
      );
    }
  }, [apiKey]);

  const handleToggle = async () => {
    if (!isActive) {
      await sayAppStart();
    }
    setActive(!isActive);
  };

  if (!permission?.granted) {
    return (
      <View style={styles.permissionView}>
        <Text style={styles.permissionText}>
          กรุณาอนุญาตให้ใช้กล้อง{'\n'}เพื่อเริ่มใช้งาน EyeAI
        </Text>
        <TouchableOpacity style={styles.permBtn} onPress={requestPermission}>
          <Text style={styles.permBtnText}>อนุญาตกล้อง</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>

      {/* กล้อง */}
      <View style={styles.cameraContainer}>
        <CameraView
          ref={cameraRef}
          style={StyleSheet.absoluteFill}
          facing="back"
        />
        <DetectionOverlay objects={currentObjects} isAnalyzing={isAnalyzing} />
        <AlertBanner topObject={isActive ? topObject : null} />
      </View>

      {/* ด้านล่าง */}
      <View style={styles.bottomPanel}>
        <AlertLog />

        {/* ปุ่มควบคุม */}
        <View style={styles.controls}>
          <TouchableOpacity
            style={[styles.btnMain, isActive ? styles.btnStop : styles.btnStart]}
            onPress={handleToggle}
            activeOpacity={0.8}
          >
            <Text style={styles.btnMainText}>
              {isActive ? '⏹ หยุดระบบ' : '▶ เริ่ม AI'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.btnIcon}
            onPress={() => navigation.navigate('Settings')}
          >
            <Text style={styles.btnIconText}>⚙️</Text>
          </TouchableOpacity>
        </View>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  cameraContainer: {
    flex: 1.4,
    position: 'relative',
    backgroundColor: '#000',
  },
  bottomPanel: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  controls: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingBottom: 16,
    paddingTop: 10,
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  btnMain: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnStart: {
    backgroundColor: COLORS.accent,
    shadowColor: COLORS.accent,
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  btnStop: {
    backgroundColor: COLORS.danger,
    shadowColor: COLORS.danger,
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  btnMainText: {
    color: '#000',
    fontWeight: '700',
    fontSize: 16,
  },
  btnIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnIconText: { fontSize: 20 },
  permissionView: {
    flex: 1,
    backgroundColor: COLORS.bg,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 20,
  },
  permissionText: {
    color: COLORS.text,
    fontSize: 18,
    textAlign: 'center',
    lineHeight: 28,
  },
  permBtn: {
    backgroundColor: COLORS.accent,
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 14,
  },
  permBtnText: {
    color: '#000',
    fontWeight: '700',
    fontSize: 16,
  },
});
