// ==========================================
// hooks/useCamera.ts
// Hook จัดการกล้องและการส่งภาพ AI
// ==========================================

import { useRef, useEffect, useCallback } from 'react';
import { CameraView } from 'expo-camera';
import { useAppStore } from '../store/appStore';
import { analyzeImage, prioritizeObjects, getAlertObjects } from '../services/claudeVision';
import { alertMultipleObjects, sayClear } from '../services/speechService';

export function useCamera() {
  const cameraRef = useRef<CameraView>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastAlertTime = useRef<number>(0);

  const {
    isActive,
    isAnalyzing,
    apiKey,
    settings,
    setAnalyzing,
    setResult,
    addLog,
  } = useAppStore();

  // ==========================================
  // ถ่ายภาพและส่งไป AI วิเคราะห์
  // ==========================================
  const captureAndAnalyze = useCallback(async () => {
    if (!cameraRef.current || isAnalyzing || !apiKey) return;

    try {
      setAnalyzing(true);

      // ถ่ายภาพ
      const photo = await cameraRef.current.takePictureAsync({
        base64: true,
        quality: 0.5,   // ลดขนาดเพื่อส่ง API เร็วขึ้น
        skipProcessing: true,
      });

      if (!photo?.base64) return;

      // ส่งไปวิเคราะห์
      const result = await analyzeImage(photo.base64, apiKey);
      setResult(result);

      // จัดการแจ้งเตือน
      const sortedObjects = prioritizeObjects(result.objects);
      const alertObjects  = getAlertObjects(sortedObjects);

      const now = Date.now();
      const cooldown = settings.captureIntervalMs * 2; // ไม่แจ้งเตือนซ้ำเร็วเกินไป

      if (alertObjects.length > 0 && now - lastAlertTime.current > cooldown) {
        lastAlertTime.current = now;

        if (settings.speechEnabled) {
          await alertMultipleObjects(alertObjects);
        }

        // บันทึก log
        alertObjects.forEach((obj) => {
          addLog(obj.speechText, obj.riskLevel);
        });

      } else if (result.overallSafe && settings.speechEnabled) {
        // บอกว่าปลอดภัยทุก 15 วินาที
        if (now - lastAlertTime.current > 15000) {
          lastAlertTime.current = now;
          sayClear();
          addLog('เส้นทางด้านหน้าปลอดภัย', 'safe');
        }
      }

    } catch (error) {
      console.error('Analysis error:', error);
      addLog('วิเคราะห์ภาพไม่ได้ ตรวจสอบอินเทอร์เน็ต', 'info');
    } finally {
      setAnalyzing(false);
    }
  }, [isAnalyzing, apiKey, settings, setAnalyzing, setResult, addLog]);

  // ==========================================
  // เริ่ม/หยุด interval ตาม isActive
  // ==========================================
  useEffect(() => {
    if (isActive) {
      captureAndAnalyze(); // วิเคราะห์ทันทีเมื่อเปิด
      intervalRef.current = setInterval(captureAndAnalyze, settings.captureIntervalMs);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isActive, settings.captureIntervalMs]);

  return { cameraRef };
}
