// ==========================================
// hooks/useVoiceCommand.ts
// รับคำสั่งเสียงจากผู้ใช้
// ==========================================
// หมายเหตุ: ใช้ expo-av สำหรับ record เสียง
// แล้วส่งไป Whisper API หรือใช้ Web Speech API (iOS/Android)

import { useState, useCallback } from 'react';
import { speak } from '../services/speechService';
import { useAppStore } from '../store/appStore';

type VoiceCommand =
  | 'WHAT_IS_AROUND'   // "มีอะไรรอบข้าง"
  | 'WHERE_AM_I'        // "ฉันอยู่ที่ไหน"
  | 'START'             // "เริ่ม"
  | 'STOP'              // "หยุด"
  | 'REPEAT'            // "พูดอีกที"
  | 'UNKNOWN';

const COMMAND_MAP: Record<string, VoiceCommand> = {
  'มีอะไร': 'WHAT_IS_AROUND',
  'รอบข้าง': 'WHAT_IS_AROUND',
  'อยู่ที่ไหน': 'WHERE_AM_I',
  'ที่นี่คือ': 'WHERE_AM_I',
  'เริ่ม': 'START',
  'เปิด': 'START',
  'หยุด': 'STOP',
  'ปิด': 'STOP',
  'พูดอีก': 'REPEAT',
  'พูดซ้ำ': 'REPEAT',
};

export function useVoiceCommand() {
  const [isListening, setIsListening] = useState(false);
  const { lastResult, setActive } = useAppStore();

  const parseCommand = (transcript: string): VoiceCommand => {
    for (const [keyword, command] of Object.entries(COMMAND_MAP)) {
      if (transcript.includes(keyword)) return command;
    }
    return 'UNKNOWN';
  };

  const handleCommand = useCallback(async (transcript: string) => {
    const command = parseCommand(transcript);

    switch (command) {
      case 'WHAT_IS_AROUND':
        if (lastResult) {
          const summary = lastResult.sceneSummary || 'ไม่มีข้อมูลการวิเคราะห์';
          await speak(summary, 'high');
        } else {
          await speak('ยังไม่มีข้อมูลการวิเคราะห์ กรุณารอสักครู่', 'high');
        }
        break;

      case 'WHERE_AM_I':
        await speak('กำลังตรวจสอบตำแหน่ง กรุณารอสักครู่');
        // TODO: ดึง GPS + Reverse Geocoding
        break;

      case 'START':
        setActive(true);
        await speak('เปิดระบบ AI แล้ว', 'high');
        break;

      case 'STOP':
        setActive(false);
        await speak('หยุดระบบแล้ว', 'high');
        break;

      case 'REPEAT':
        if (lastResult?.objects[0]) {
          await speak(lastResult.objects[0].speechText, 'high');
        }
        break;

      case 'UNKNOWN':
        // ไม่ตอบสนองคำสั่งที่ไม่รู้จัก เพื่อลดเสียงรบกวน
        break;
    }
  }, [lastResult, setActive]);

  return { isListening, setIsListening, handleCommand };
}
