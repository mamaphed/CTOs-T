// ==========================================
// components/AlertBanner.tsx
// แบนเนอร์แจ้งเตือนที่แสดงบนจอ
// ==========================================

import React, { useEffect, useRef } from 'react';
import { Animated, Text, StyleSheet, View } from 'react-native';
import { DetectedObject } from '../services/claudeVision';
import { COLORS } from '../constants';

interface Props {
  topObject: DetectedObject | null;
}

const RISK_STYLE = {
  danger: { bg: 'rgba(255,23,68,0.92)',  border: COLORS.danger },
  warn:   { bg: 'rgba(255,109,0,0.92)', border: COLORS.warn },
  safe:   { bg: 'rgba(0,230,118,0.85)', border: COLORS.safe },
};

const RISK_ICON = { danger: '⚠️', warn: '⚡', safe: '✅' };

export function AlertBanner({ topObject }: Props) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-20)).current;

  useEffect(() => {
    if (topObject) {
      Animated.parallel([
        Animated.spring(opacity,     { toValue: 1, useNativeDriver: true }),
        Animated.spring(translateY,  { toValue: 0, useNativeDriver: true, tension: 120, friction: 8 }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(opacity,    { toValue: 0, duration: 300, useNativeDriver: true }),
        Animated.timing(translateY, { toValue: -20, duration: 300, useNativeDriver: true }),
      ]).start();
    }
  }, [topObject?.name, topObject?.direction]);

  if (!topObject) return null;

  const style = RISK_STYLE[topObject.riskLevel];

  return (
    <Animated.View
      style={[
        styles.banner,
        { opacity, transform: [{ translateY }], backgroundColor: style.bg, borderColor: style.border },
      ]}
    >
      <Text style={styles.icon}>{RISK_ICON[topObject.riskLevel]}</Text>
      <Text style={styles.text}>{topObject.speechText}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  banner: {
    position: 'absolute',
    top: 24,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 30,
    borderWidth: 1,
    zIndex: 99,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 10,
    maxWidth: '90%',
  },
  icon: { fontSize: 18 },
  text: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
    flexShrink: 1,
  },
});
