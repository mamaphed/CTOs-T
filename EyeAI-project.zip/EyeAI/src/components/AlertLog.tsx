// ==========================================
// components/AlertLog.tsx
// รายการประวัติการแจ้งเตือน
// ==========================================

import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useAppStore } from '../store/appStore';
import { COLORS } from '../constants';

const RISK_COLOR = {
  danger: COLORS.danger,
  warn:   COLORS.warn,
  safe:   COLORS.safe,
  info:   COLORS.muted,
};

const RISK_ICON = { danger: '⚠️', warn: '⚡', safe: '✅', info: 'ℹ️' };

export function AlertLog() {
  const { alertLog, clearLog } = useAppStore();

  const formatTime = (date: Date) =>
    `${String(date.getHours()).padStart(2, '0')}:` +
    `${String(date.getMinutes()).padStart(2, '0')}:` +
    `${String(date.getSeconds()).padStart(2, '0')}`;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <View style={[styles.recDot]} />
          <Text style={styles.title}>บันทึกการแจ้งเตือน</Text>
        </View>
        {alertLog.length > 0 && (
          <TouchableOpacity onPress={clearLog}>
            <Text style={styles.clearBtn}>ล้าง</Text>
          </TouchableOpacity>
        )}
      </View>

      {alertLog.length === 0 ? (
        <Text style={styles.empty}>ยังไม่มีการแจ้งเตือน</Text>
      ) : (
        <FlatList
          data={alertLog}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          style={styles.list}
          renderItem={({ item }) => {
            const color = RISK_COLOR[item.riskLevel];
            return (
              <View style={[styles.item, { borderLeftColor: color }]}>
                <Text style={styles.itemIcon}>{RISK_ICON[item.riskLevel]}</Text>
                <Text style={styles.itemText} numberOfLines={2}>{item.text}</Text>
                <Text style={styles.itemTime}>{formatTime(item.timestamp)}</Text>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  recDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: COLORS.danger,
  },
  title: {
    color: COLORS.muted,
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  clearBtn: {
    color: COLORS.accent,
    fontSize: 12,
  },
  empty: {
    color: COLORS.muted,
    fontSize: 12,
    textAlign: 'center',
    marginTop: 16,
  },
  list: { flex: 1 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: COLORS.card,
    borderRadius: 10,
    marginBottom: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderLeftWidth: 3,
  },
  itemIcon: { fontSize: 14 },
  itemText: {
    flex: 1,
    color: COLORS.text,
    fontSize: 12,
    lineHeight: 18,
  },
  itemTime: {
    color: COLORS.muted,
    fontSize: 10,
    fontFamily: 'monospace',
    flexShrink: 0,
  },
});
