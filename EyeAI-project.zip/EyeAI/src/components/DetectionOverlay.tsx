// ==========================================
// components/DetectionOverlay.tsx
// กรอบ AI detection ซ้อนบนหน้ากล้อง
// ==========================================

import React from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { DetectedObject } from '../services/claudeVision';
import { COLORS } from '../constants';

interface Props {
  objects: DetectedObject[];
  isAnalyzing: boolean;
}

const RISK_COLOR = {
  danger: COLORS.danger,
  warn:   COLORS.warn,
  safe:   COLORS.safe,
};

// สี badge ตาม direction
const DIRECTION_POSITION = {
  'ซ้าย':  { left: '5%',   top: '30%' },
  'ขวา':  { right: '5%',  top: '30%' },
  'หน้า': { left: '35%',  top: '10%' },
  'หลัง': { left: '35%',  bottom: '10%' },
};

export function DetectionOverlay({ objects, isAnalyzing }: Props) {
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">

      {/* มุมกรอบกล้อง */}
      <View style={[styles.corner, styles.topLeft]} />
      <View style={[styles.corner, styles.topRight]} />
      <View style={[styles.corner, styles.bottomLeft]} />
      <View style={[styles.corner, styles.bottomRight]} />

      {/* Scan line เมื่อกำลังวิเคราะห์ */}
      {isAnalyzing && <View style={styles.scanLine} />}

      {/* Badge แต่ละวัตถุ */}
      {objects
        .filter((o) => o.riskLevel !== 'safe')
        .map((obj, i) => {
          const color = RISK_COLOR[obj.riskLevel];
          const pos = DIRECTION_POSITION[obj.direction] ?? { left: '35%', top: '30%' };

          return (
            <View key={i} style={[styles.badge, pos, { borderColor: color }]}>
              <Text style={[styles.badgeText, { color }]}>
                {obj.name}
              </Text>
              <Text style={[styles.distText, { color }]}>
                {obj.estimatedDistance.toFixed(1)} ม.
              </Text>
            </View>
          );
        })}

      {/* สถานะ AI */}
      <View style={styles.statusChip}>
        <View style={[styles.dot, { backgroundColor: isAnalyzing ? COLORS.warn : COLORS.safe }]} />
        <Text style={styles.statusText}>
          {isAnalyzing ? 'กำลังวิเคราะห์...' : 'AI พร้อม'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  corner: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderColor: COLORS.accent,
  },
  topLeft:     { top: 16, left: 16,  borderTopWidth: 2, borderLeftWidth: 2 },
  topRight:    { top: 16, right: 16, borderTopWidth: 2, borderRightWidth: 2 },
  bottomLeft:  { bottom: 16, left: 16,  borderBottomWidth: 2, borderLeftWidth: 2 },
  bottomRight: { bottom: 16, right: 16, borderBottomWidth: 2, borderRightWidth: 2 },

  scanLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: '50%',
    height: 2,
    backgroundColor: COLORS.accent,
    opacity: 0.6,
    shadowColor: COLORS.accent,
    shadowOpacity: 1,
    shadowRadius: 8,
  },

  badge: {
    position: 'absolute',
    borderWidth: 1.5,
    borderRadius: 8,
    padding: 6,
    backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center',
    minWidth: 70,
  },
  badgeText: {
    fontWeight: '700',
    fontSize: 13,
  },
  distText: {
    fontSize: 11,
    opacity: 0.9,
  },

  statusChip: {
    position: 'absolute',
    bottom: 16,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
    gap: 6,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: COLORS.text,
    fontSize: 11,
    fontWeight: '500',
  },
});
