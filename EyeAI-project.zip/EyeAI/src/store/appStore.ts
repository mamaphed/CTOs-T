// ==========================================
// store/appStore.ts
// State ส่วนกลางของแอปด้วย Zustand
// ==========================================

import { create } from 'zustand';
import { DetectedObject, AnalysisResult } from '../services/claudeVision';

interface AlertLog {
  id: string;
  text: string;
  riskLevel: 'danger' | 'warn' | 'safe' | 'info';
  timestamp: Date;
}

interface AppState {
  // การทำงาน
  isActive: boolean;
  isAnalyzing: boolean;
  apiKey: string;

  // ผลการวิเคราะห์
  lastResult: AnalysisResult | null;
  currentObjects: DetectedObject[];

  // บันทึกแจ้งเตือน
  alertLog: AlertLog[];

  // การตั้งค่า
  settings: {
    speechEnabled: boolean;
    vibrationEnabled: boolean;
    captureIntervalMs: number;
    sensitivity: 'low' | 'medium' | 'high';
    language: 'th' | 'en';
  };

  // Actions
  setActive: (active: boolean) => void;
  setAnalyzing: (analyzing: boolean) => void;
  setApiKey: (key: string) => void;
  setResult: (result: AnalysisResult) => void;
  addLog: (text: string, riskLevel: AlertLog['riskLevel']) => void;
  clearLog: () => void;
  updateSettings: (settings: Partial<AppState['settings']>) => void;
}

export const useAppStore = create<AppState>((set) => ({
  // ค่าเริ่มต้น
  isActive: false,
  isAnalyzing: false,
  apiKey: '',

  lastResult: null,
  currentObjects: [],

  alertLog: [],

  settings: {
    speechEnabled: true,
    vibrationEnabled: true,
    captureIntervalMs: 1500,
    sensitivity: 'medium',
    language: 'th',
  },

  // Actions
  setActive: (active) => set({ isActive: active }),
  setAnalyzing: (analyzing) => set({ isAnalyzing: analyzing }),
  setApiKey: (key) => set({ apiKey: key }),

  setResult: (result) =>
    set({
      lastResult: result,
      currentObjects: result.objects,
    }),

  addLog: (text, riskLevel) =>
    set((state) => ({
      alertLog: [
        {
          id: Date.now().toString(),
          text,
          riskLevel,
          timestamp: new Date(),
        },
        ...state.alertLog.slice(0, 49), // เก็บแค่ 50 รายการล่าสุด
      ],
    })),

  clearLog: () => set({ alertLog: [] }),

  updateSettings: (newSettings) =>
    set((state) => ({
      settings: { ...state.settings, ...newSettings },
    })),
}));
