// ==========================================
// services/speechService.ts
// บริการแปลงข้อความเป็นเสียงพูดภาษาไทย
// ==========================================

import * as Speech from 'expo-speech';
import * as Haptics from 'expo-haptics';
import { DetectedObject } from './claudeVision';
import { SPEECH_MESSAGES } from '../constants';

// ==========================================
// พูดข้อความภาษาไทย
// ==========================================
export async function speak(text: string, priority: 'high' | 'normal' = 'normal') {
  // หยุดเสียงเดิมถ้า priority สูง
  if (priority === 'high') {
    await Speech.stop();
  }

  const isSpeaking = await Speech.isSpeakingAsync();
  if (isSpeaking && priority === 'normal') return; // ไม่พูดทับ

  Speech.speak(text, {
    language: 'th-TH',
    pitch: 1.0,
    rate: 0.9,   // ช้าลงนิดหน่อยเพื่อฟังชัด
  });
}

// ==========================================
// แจ้งเตือนตามระดับความเสี่ยง
// ==========================================
export async function alertByRisk(obj: DetectedObject) {
  if (obj.riskLevel === 'danger') {
    // สั่นแรง + พูดเร่งด่วน
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    await speak(obj.speechText, 'high');

  } else if (obj.riskLevel === 'warn') {
    // สั่นเบา + พูดปกติ
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await speak(obj.speechText);
  }
  // safe → ไม่พูด ไม่สั่น (ลดเสียงรบกวน)
}

// ==========================================
// แจ้งเตือนวัตถุหลายชิ้น (เรียงตามความสำคัญ)
// ==========================================
export async function alertMultipleObjects(objects: DetectedObject[]) {
  const dangerous = objects.filter((o) => o.riskLevel === 'danger');
  const warnings  = objects.filter((o) => o.riskLevel === 'warn');

  if (dangerous.length > 0) {
    // พูดอันตรายทั้งหมดรวมกัน
    const text = dangerous.map((o) => o.speechText).join(' และ ');
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    await speak(text, 'high');

  } else if (warnings.length > 0) {
    // พูดคำเตือนชิ้นแรกก่อน
    await alertByRisk(warnings[0]);
  }
}

// ==========================================
// พูดข้อความสำเร็จรูป
// ==========================================
export const sayAppStart  = () => speak(SPEECH_MESSAGES.appStart);
export const sayClear     = () => speak(SPEECH_MESSAGES.allClear);
export const sayNoInternet = () => speak(SPEECH_MESSAGES.noInternet, 'high');
