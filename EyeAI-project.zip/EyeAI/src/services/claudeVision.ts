// ==========================================
// services/claudeVision.ts
// บริการวิเคราะห์ภาพด้วย Claude AI
// ==========================================

import { VISION_PROMPT } from '../constants';

export interface DetectedObject {
  name: string;
  direction: 'ซ้าย' | 'ขวา' | 'หน้า' | 'หลัง';
  estimatedDistance: number;
  riskLevel: 'danger' | 'warn' | 'safe';
  speechText: string;
}

export interface AnalysisResult {
  objects: DetectedObject[];
  overallSafe: boolean;
  sceneSummary: string;
  timestamp: number;
}

// ==========================================
// วิเคราะห์ภาพด้วย Claude Vision API
// ==========================================
export async function analyzeImage(
  base64Image: string,
  apiKey: string
): Promise<AnalysisResult> {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-opus-4-6',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: 'image/jpeg',
                data: base64Image,
              },
            },
            {
              type: 'text',
              text: VISION_PROMPT,
            },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`Claude API Error: ${response.status}`);
  }

  const data = await response.json();
  const rawText = data.content[0]?.text ?? '{}';

  // ดึง JSON ออกจากข้อความ (กรณี model ใส่ข้อความอื่นมาด้วย)
  const jsonMatch = rawText.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('Invalid response format');

  const parsed = JSON.parse(jsonMatch[0]);

  return {
    ...parsed,
    timestamp: Date.now(),
  };
}

// ==========================================
// เรียงลำดับความสำคัญของวัตถุ
// danger ก่อน → warn → safe
// ==========================================
export function prioritizeObjects(objects: DetectedObject[]): DetectedObject[] {
  const priority = { danger: 0, warn: 1, safe: 2 };
  return [...objects].sort(
    (a, b) => priority[a.riskLevel] - priority[b.riskLevel]
  );
}

// ==========================================
// กรองเฉพาะวัตถุที่ต้องแจ้งเตือน
// ==========================================
export function getAlertObjects(objects: DetectedObject[]): DetectedObject[] {
  return objects.filter((obj) => obj.riskLevel !== 'safe');
}
