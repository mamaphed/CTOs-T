# 👁️ EyeAI — ผู้ช่วยสายตา AI

แอปมือถือ React Native ที่ช่วยผู้พิการทางสายตา โดยใช้ AI วิเคราะห์ภาพจากกล้องและแจ้งเตือนเสียงภาษาไทยแบบ Real-time

---

## 🏗️ โครงสร้างโปรเจกต์

```
EyeAI/
├── App.tsx                          # จุดเริ่มต้น + Navigation
├── app.json                         # Expo config + Permissions
├── package.json                     # Dependencies
│
└── src/
    ├── constants/
    │   └── index.ts                 # สี, ข้อความ, ค่าคงที่ทั้งหมด
    │
    ├── services/
    │   ├── claudeVision.ts          # ส่งภาพไป Claude API + parse ผล
    │   └── speechService.ts         # Text-to-Speech + Haptics
    │
    ├── hooks/
    │   ├── useCamera.ts             # จับภาพ + ส่ง AI อัตโนมัติ
    │   └── useVoiceCommand.ts       # รับคำสั่งเสียงจากผู้ใช้
    │
    ├── store/
    │   └── appStore.ts              # Global state (Zustand)
    │
    ├── components/
    │   ├── DetectionOverlay.tsx     # กรอบ AI ซ้อนบนกล้อง
    │   ├── AlertBanner.tsx          # แบนเนอร์แจ้งเตือนบนหน้าจอ
    │   └── AlertLog.tsx             # รายการประวัติการแจ้งเตือน
    │
    └── screens/
        ├── CameraScreen.tsx         # หน้าจอหลัก
        └── SettingsScreen.tsx       # หน้าตั้งค่า
```

---

## 🚀 วิธีติดตั้งและรัน

### 1. ติดตั้ง Dependencies

```bash
npm install
```

### 2. รันบนมือถือ

```bash
# iOS Simulator
npx expo start --ios

# Android Emulator
npx expo start --android

# ทดสอบบนมือถือจริงด้วย Expo Go
npx expo start
```

### 3. ตั้งค่า API Key

- เปิดแอป → กดปุ่ม ⚙️ ตั้งค่า
- ใส่ Claude API Key (รับได้ที่ https://console.anthropic.com)
- กด "บันทึก"

---

## 🔑 การได้มาซึ่ง Claude API Key

1. ไปที่ https://console.anthropic.com
2. สมัครสมาชิก / เข้าสู่ระบบ
3. ไปที่ **API Keys** → **Create Key**
4. คัดลอก key ที่ขึ้นต้นด้วย `sk-ant-...`
5. ใส่ใน Settings ของแอป

---

## ⚙️ การทำงานของระบบ

```
กล้องถ่ายภาพทุก 1.5 วินาที
        ↓
ส่ง Base64 image ไป Claude Vision API
        ↓
Claude วิเคราะห์และส่งกลับ JSON:
  - ชื่อวัตถุ (ภาษาไทย)
  - ทิศทาง (ซ้าย/ขวา/หน้า/หลัง)
  - ระยะห่าง (เมตร)
  - ระดับอันตราย (danger/warn/safe)
        ↓
ระบบตัดสินใจ:
  danger (<2m) → สั่นแรง + พูดเร่งด่วน
  warn   (<4m) → สั่นเบา + พูดปกติ
  safe         → ไม่แจ้งเตือน (ลดเสียงรบกวน)
        ↓
เสียงพูดภาษาไทย + การสั่น
```

---

## 📦 Dependencies หลัก

| Package | การใช้งาน |
|---------|-----------|
| `expo-camera` | ถ่ายภาพแบบ real-time |
| `expo-speech` | Text-to-Speech ภาษาไทย |
| `expo-haptics` | การสั่นตามระดับอันตราย |
| `expo-location` | GPS สำหรับบอกตำแหน่ง |
| `@anthropic-ai/sdk` | Claude Vision API |
| `zustand` | Global state management |
| `react-navigation` | Navigation ระหว่างหน้า |

---

## 🔮 Feature ถัดไป

- [ ] คำสั่งเสียง "มีอะไรรอบข้าง" / "ฉันอยู่ที่ไหน"
- [ ] โหมด Offline ด้วย MobileNet/YOLO Lite (ไม่ต้องอินเทอร์เน็ต)
- [ ] Navigation ด้วย GPS + แผนที่
- [ ] รู้จำใบหน้าคนรู้จัก
- [ ] อ่านป้ายหรือข้อความในภาพ (OCR)
- [ ] การแจ้งเตือนแบบ Earcons (เสียงสัญลักษณ์)
